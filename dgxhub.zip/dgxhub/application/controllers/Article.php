<?php

/**
 * This is the controller class for the API with user
 * interaction method - VIEW, CREATE, UPDATE, DELETE
 *
 */
class Article extends CI_Controller
{
    public function __construct()
    {
        //Construct the parent class
        parent :: __construct();
        $this->load->model('article_model');
        $this->load->helper('url_helper');
    }

    /**
     * Method to initialise for getting all the values
     *
     */
    public function index()
    {
        $data['articles'] = $this->article_model->get_articles();
        $this->load->view('article/index', $data);
    }

    /**
     * Method for getting the data for specific id
     * @param id [in] ID of the data entry
     */
    public function view($id=0)
    {
        $data['articles'] = $this->article_model->get_articles($id);
        if (!$data['articles'])
        {
            show_404();
        }
        $this->load->view('article/index', $data);
    }
    /**
     * Method for deleting an entry from the database
     * @param id [in] id of the entry to be deleted
     */
    public function delete($id=0)
    {
        $data['articles'] = $this->article_model->delete_articles($id);
        if (!$data['articles'])
        {
            show_404();
        }
        $this->load->view('article/success', $data);
    }

    /**
     * Method to create new entry into the database
     *
     */
    public function create()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('text', 'Text', 'required');

        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('article/create');

        }
        else
        {
            $this->article_model->set_article();
            $this->load->view('article/success');
        }
    }

    /**
     * Method for updating the entry from the database
     * 
     */
    public function update()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('body', 'Body', 'required');

        if($this->form_validation->run() === FALSE)
        {
            $this->load->view('article/update');
        }
        else
        {
            $this->article_model->update_article();
            $this->load->view('article/success');
        }
    }

}
