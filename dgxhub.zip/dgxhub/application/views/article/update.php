

<?php echo validation_errors(); ?>

<?php echo form_open('article/update'); ?>

    <label for="id">Id</label>
    <input type="input" name="id" /><br />

    <label for="title">Title</label>
    <input type="input" name="title" /><br />

    <label for="body">Body</label>
    <textarea name="body"></textarea><br />

    <input type="submit" name="submit" value="Update article" />

</form>
