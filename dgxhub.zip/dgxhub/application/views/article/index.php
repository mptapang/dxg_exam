<?php

echo $articles; 
