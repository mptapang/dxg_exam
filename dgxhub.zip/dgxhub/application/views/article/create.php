<?php echo validation_errors(); ?>

<?php echo form_open('article/create'); ?>

    <label for="title">Title</label>
    <input type="input" name="title" /><br />

    <label for="text">Body</label>
    <textarea name="text"></textarea><br />

    <input type="submit" name="submit" value="Create new article" />

</form>
