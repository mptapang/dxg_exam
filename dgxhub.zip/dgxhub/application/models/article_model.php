<?php
/**
 * This class model is use for the Article controller
 *
 */
class Article_model extends CI_Model
{
    /** Constructor */
    public function __construct()
    {
        $this->load->database();
    }

    /**
     * Method to get the article entry from the database
     * @param id [in] ID of the article to be query
     */
    public function get_articles($id=0)
    {
        //return only the id, title and body column
        $this->db->select('id, title, body');
        //if no id passed, return all the data from the table
        if(!$id){
            $query = $this->db->get('article');
            return json_encode($query->result_array());
        }
        $query = $this->db->get_where('article',array('id'=>$id));
        return json_encode($query->row_array());
    }

    /**
     * Method to delete entry from the table
     * @param in [in] ID to be deleted
     */
    public function delete_articles($id=0)
    {
        $this->load->helper('url');

        return $this->db->delete('article', array('id' => $id));
    }

    /**
     * Method for adding article entry into the database
     *
     */
    public function set_article()
    {
        $this->load->helper('url');

        //initially, updated_at and created_at will be the same
        $data = array(
            'title' => $this->input->post('title'),
            'body' => $this->input->post('text'),
            'created_at' => date('Y-m-d h:i:s'),
            'updated_at' => date('Y-m-d h:i:s')
        );

        return $this->db->insert('article', $data);
    }

    /**
     * Method for updating the entry from the table
     * and update the updated_at for each entry
     */
    public function update_article()
    {
        $this->load->helper('url');

        $data = array(
            'title' => $this->input->post('title'),
            'body' => $this->input->post('body'),
            'updated_at' => date('Y-m-d h:i:s')
        );
        $id = $this->input->post('id');

        $this->db->where('id',$id);
        return $this->db->update('article',$data);
    }
}
