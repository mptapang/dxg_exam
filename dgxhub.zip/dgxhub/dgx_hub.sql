create table `article` (
  id INT(10) NOT NULL AUTO_INCREMENT,
  title VARCHAR(250) NOT NULL,
  body VARCHAR(500),
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id));
